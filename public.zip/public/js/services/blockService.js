webApp.service('blockService', function () {
    this.lastBlockId = null;
});